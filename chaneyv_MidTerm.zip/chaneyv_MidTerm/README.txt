Midterm - BMP180
Wayne Chaney

File Structure:
/chaneyv_Midterm
	chaneyv_MidTerm/BMP180Button
		chaneyv_MidTerm/BMP180Button/BMP180Button.c
		compile_script.py
	chaneyv_lab4/BMP180
		chaneyv_Midterm/BMP180/BMP180.c
		compile_script.py

Instructions for compilation and upload:
	1. Modify the python script to include the directory of your WinAVR and the corresponding COM port of your Arduino
	2. Navigate to the corresponding directory (/chaneyv_Midterm/BMP180Button.c or /chaneyv_Midterm/BMP180.c) within your command line and run the python compile script.

Usage:
	To operate the system, utilize the first button (Arduino Digital Pin 7) to open the menu or use the second button (Arduino Digital Pin 6 to cycle through names, button press count, and course number and section.