#include <stdint.h>
#include "lib/hd44780.h"

int main(void)
{
	//Setup
	LCD_Setup();
	
	//Print Pressure and Temperture
	uint8_t line;
	for (line = 0; line < 2; line++)
	{
		LCD_GotoXY(0, line);
		if (line == 0)
		{
			LCD_PrintString("Pressure: ");
			LCD_PrintInteger(LCD_GetY());
		}
		else 
		{
			LCD_PrintString("Temperture");
			LCD_PrintInteger(LCD_GetY());
	
		}
	}
	
	while (1);
	
	return 0;
}
