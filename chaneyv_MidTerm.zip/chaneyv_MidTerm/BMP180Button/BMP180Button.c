#include <stdint.h>
#include "lib/hd44780.h"

// Define Button Ports
#define MY_BUTTON1 PD7
#define MY_BUTTON2 PD6 

// Declare method to check for button presses
short check_button_press_and_release(int button);

int main(void)
{
	//Setup
	LCD_Setup();
	
	// Variable to track the number of presses
	int count = 0;
	while(1) 
	{
		// Check that button 2 was pressed
		if (check_button_press_and_release(MY_BUTTON2)) {
			count++;
			// Display Name
			if (count % 3 == 1) {
				LCD_Clear();
				LCD_GotoXY(0, 0);
				LCD_PrintString("Wayne Chaney");
				
			}
	
		
		}

	}
}

// Method to check for button presses
short check_button_press_and_release(int button)
{
	int ret_val = 0;

	if ((PIND & (1 << button)) != 0)
	{
		/* software debounce */
		_delay_ms(15);
		if ((PIND & (1 << button)) != 0)
		{
			/* wait for button to be released */
			while((PIND & (1 << button)) != 0)
				ret_val = 1;
		}
	}

	return ret_val;
}
